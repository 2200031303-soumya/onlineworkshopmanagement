import React, { useEffect, useState } from 'react';
import axios from '../services/api';

const WorkshopList = () => {
  const [workshops, setWorkshops] = useState([]);

  useEffect(() => {
    axios.get('/workshops')
      .then(response => setWorkshops(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <div className="container mt-4">
      <h2>Available Workshops</h2>
      <div className="row">
        {workshops.map(workshop => (
          <div className="col-md-4" key={workshop.id}>
            <div className="card mb-3">
              <div className="card-body">
                <h5 className="card-title">{workshop.title}</h5>
                <p className="card-text">{workshop.description}</p>
                <a href={`/workshops/${workshop.id}`} className="btn btn-primary">Details</a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WorkshopList;