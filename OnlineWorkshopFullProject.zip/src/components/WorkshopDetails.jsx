import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from '../services/api';

const WorkshopDetails = () => {
  const { id } = useParams();
  const [workshop, setWorkshop] = useState(null);

  useEffect(() => {
    axios.get(`/workshops/${id}`)
      .then(response => setWorkshop(response.data))
      .catch(error => console.error(error));
  }, [id]);

  if (!workshop) return <p>Loading...</p>;

  return (
    <div className="container mt-4">
      <h2>{workshop.title}</h2>
      <p>{workshop.description}</p>
      <p><strong>Date:</strong> {workshop.date}</p>
      <button className="btn btn-success">Register</button>
    </div>
  );
};

export default WorkshopDetails;