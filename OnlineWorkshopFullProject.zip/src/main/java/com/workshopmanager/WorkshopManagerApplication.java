package com.workshopmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkshopManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(WorkshopManagerApplication.class, args);
    }
}