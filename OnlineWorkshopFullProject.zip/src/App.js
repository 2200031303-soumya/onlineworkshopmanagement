import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import WorkshopList from './components/WorkshopList';
import WorkshopDetails from './components/WorkshopDetails';
import RegistrationForm from './components/RegistrationForm';

const App = () => {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<WorkshopList />} />
        <Route path="/workshops/:id" element={<WorkshopDetails />} />
        <Route path="/register" element={<RegistrationForm />} />
      </Routes>
    </Router>
  );
};

export default App;